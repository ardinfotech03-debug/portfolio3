import React, { useState, useEffect, useCallback } from 'react';
import { useTheme } from '@/hooks/useTheme';
import { useRobotMode } from '@/hooks/useRobotMode';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import CRTEffect from '@/components/CRTEffect';
import WhatsAppButton from '@/components/WhatsAppButton';
import Toast from '@/components/Toast';
import LoadingScreen from '@/sections/LoadingScreen';
import Navigation from '@/sections/Navigation';
import Home from '@/sections/Home';
import About from '@/sections/About';
import Education from '@/sections/Education';
import Internship from '@/sections/Internship';
import Projects from '@/sections/Projects';
import Skills from '@/sections/Skills';
import Certificates from '@/sections/Certificates';
import Reviews from '@/sections/Reviews';
import Contact from '@/sections/Contact';
import Footer from '@/sections/Footer';

const App: React.FC = () => {
  const { theme, cycleTheme } = useTheme();
  const { mode: robotMode, cycleMode, toast } = useRobotMode();
  const [loading, setLoading] = useState(true);

  useScrollAnimation();

  // Scroll to section handler
  const scrollTo = useCallback((id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const offset = 80;
      const top = el.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  }, []);

  // Handle loading complete
  const handleLoadingComplete = useCallback(() => {
    setLoading(false);
  }, []);

  // Apply theme on mount
  useEffect(() => {
    document.documentElement.style.setProperty('--bg-color', theme.bg);
    document.documentElement.style.setProperty('--text-primary', theme.text);
    document.documentElement.style.setProperty('--accent-color', theme.accent);
    document.documentElement.style.setProperty('--accent-secondary', theme.accentSecondary);
    
    const r = parseInt(theme.accent.slice(1, 3), 16);
    const g = parseInt(theme.accent.slice(3, 5), 16);
    const b = parseInt(theme.accent.slice(5, 7), 16);
    document.documentElement.style.setProperty('--primary', `${r}, ${g}, ${b}`);
    document.documentElement.style.setProperty('--accent', `${r}, ${g}, ${b}`);
    document.documentElement.style.setProperty('--ring', `${r}, ${g}, ${b}`);
    
    document.body.style.backgroundColor = theme.bg;
    document.body.style.color = theme.text;
  }, [theme]);

  return (
    <div
      className="min-h-screen transition-colors duration-500"
      style={{ backgroundColor: 'var(--bg-color)', color: 'var(--text-primary)' }}
    >
      {/* CRT Effects Overlay */}
      <CRTEffect />

      {/* Loading Screen */}
      {loading && <LoadingScreen onComplete={handleLoadingComplete} />}

      {/* Main Content */}
      {!loading && (
        <>
          <Navigation onNavigate={scrollTo} />

          <main>
            <Home robotMode={robotMode} onNavigate={scrollTo} />
            <About />
            <Education />
            <Internship />
            <Projects />
            <Skills />
            <Certificates />
            <Reviews />
            <Contact />
          </main>

          <Footer
            themeName={theme.name}
            onCycleTheme={cycleTheme}
            onNavigate={scrollTo}
          />

          {/* WhatsApp Floating Button */}
          <WhatsAppButton onLongPress={cycleMode} />

          {/* Toast Notification */}
          <Toast message={toast} />
        </>
      )}
    </div>
  );
};

export default App;
