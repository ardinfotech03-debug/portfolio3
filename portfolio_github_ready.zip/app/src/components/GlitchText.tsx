import React, { useState, useEffect, useCallback } from 'react';

interface GlitchTextProps {
  text: string;
  className?: string;
  interval?: number;
}

const GlitchText: React.FC<GlitchTextProps> = ({ text, className = '', interval = 8000 }) => {
  const [glitching, setGlitching] = useState(false);

  const triggerGlitch = useCallback(() => {
    setGlitching(true);
    setTimeout(() => setGlitching(false), 300);
  }, []);

  useEffect(() => {
    const timer = setInterval(triggerGlitch, interval);
    return () => clearInterval(timer);
  }, [triggerGlitch, interval]);

  return (
    <span className={`relative inline-block ${className}`} onMouseEnter={triggerGlitch}>
      <span className={glitching ? 'glitch-active' : ''}>{text}</span>
      {glitching && (
        <>
          <span
            className="absolute top-0 left-0 w-full h-full glitch-active"
            style={{ color: 'var(--accent-color)', opacity: 0.7, clipPath: 'inset(20% 0 60% 0)' }}
            aria-hidden="true"
          >
            {text}
          </span>
          <span
            className="absolute top-0 left-0 w-full h-full glitch-active"
            style={{ color: 'var(--accent-secondary)', opacity: 0.5, clipPath: 'inset(60% 0 20% 0)' }}
            aria-hidden="true"
          >
            {text}
          </span>
        </>
      )}
    </span>
  );
};

export default GlitchText;
