import React, { useRef, useEffect, useMemo, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';
import type { RobotMode } from '@/types';

/* ─── Single Particle for Mode B ─── */
interface ParticleProps {
  origin: THREE.Vector3;
}

const Particle: React.FC<ParticleProps> = ({ origin }) => {
  const ref = useRef<THREE.Mesh>(null);
  const velocity = useRef(
    new THREE.Vector3(
      (Math.random() - 0.5) * 0.08,
      Math.random() * 0.1 + 0.02,
      (Math.random() - 0.5) * 0.08
    )
  );
  const life = useRef(Math.random() * 60 + 30);

  useFrame(() => {
    if (!ref.current) return;
    ref.current.position.add(velocity.current);
    velocity.current.y += 0.001;
    velocity.current.x *= 0.98;
    velocity.current.z *= 0.98;
    life.current--;
    const scale = Math.max(0, life.current / 60);
    ref.current.scale.setScalar(scale * 0.08);
    if (life.current <= 0) {
      ref.current.position.copy(origin);
      velocity.current.set(
        (Math.random() - 0.5) * 0.08,
        Math.random() * 0.1 + 0.02,
        (Math.random() - 0.5) * 0.08
      );
      life.current = Math.random() * 60 + 30;
    }
  });

  return (
    <mesh ref={ref} position={origin.clone()}>
      <boxGeometry args={[1, 1, 1]} />
      <meshBasicMaterial color="#FFAA00" transparent opacity={0.9} />
    </mesh>
  );
};

/* ─── Robot Head with Eyes ─── */
interface RobotHeadProps {
  mode: RobotMode;
  mousePos: React.MutableRefObject<{ x: number; y: number }>;
  emotion: string;
}

const RobotHead: React.FC<RobotHeadProps> = ({ mode, mousePos, emotion }) => {
  const headRef = useRef<THREE.Group>(null);
  const leftEyeRef = useRef<THREE.Mesh>(null);
  const rightEyeRef = useRef<THREE.Mesh>(null);
  const antennaRef = useRef<THREE.Mesh>(null);
  const blinkRef = useRef(0);

  useFrame((state) => {
    if (!headRef.current) return;
    const t = state.clock.getElapsedTime();

    // Gentle floating
    headRef.current.position.y = Math.sin(t * 1.5) * 0.05 + 1.6;

    // Mouse tracking (head follows cursor)
    const targetX = mousePos.current.x * 0.3;
    const targetY = mousePos.current.y * 0.2;
    headRef.current.rotation.y = THREE.MathUtils.lerp(headRef.current.rotation.y, targetX, 0.05);
    headRef.current.rotation.x = THREE.MathUtils.lerp(headRef.current.rotation.x, -targetY, 0.05);

    // Blinking
    blinkRef.current += 1;
    if (blinkRef.current > 120) {
      if (blinkRef.current > 130) blinkRef.current = 0;
      if (leftEyeRef.current) leftEyeRef.current.scale.y = 0.1;
      if (rightEyeRef.current) rightEyeRef.current.scale.y = 0.1;
    } else {
      if (leftEyeRef.current) leftEyeRef.current.scale.y = 1;
      if (rightEyeRef.current) rightEyeRef.current.scale.y = 1;
    }

    // Antenna blink
    if (antennaRef.current) {
      const mat = antennaRef.current.material as THREE.MeshStandardMaterial;
      mat.emissiveIntensity = Math.sin(t * 4) > 0 ? 0.8 : 0.2;
    }
  });

  const accentColor = mode === 'C' ? '#00FFCC' : mode === 'B' ? '#00CCFF' : '#00FFCC';

  const getEyeExpression = () => {
    switch (emotion) {
      case 'happy':
        return { left: { x: -0.25, y: 0, s: 1.1 }, right: { x: 0.25, y: 0, s: 1.1 } };
      case 'sad':
        return { left: { x: -0.25, y: -0.05, s: 0.8 }, right: { x: 0.25, y: -0.05, s: 0.8 } };
      case 'angry':
        return { left: { x: -0.28, y: 0.05, s: 0.9 }, right: { x: 0.28, y: 0.05, s: 0.9 } };
      default:
        return { left: { x: -0.25, y: 0, s: 1 }, right: { x: 0.25, y: 0, s: 1 } };
    }
  };

  const expr = getEyeExpression();

  const headMaterial = useMemo(() => {
    if (mode === 'C') {
      return new THREE.MeshBasicMaterial({ color: accentColor, wireframe: true, transparent: true, opacity: 0.8 });
    }
    if (mode === 'B') {
      return new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9, roughness: 0.1 });
    }
    return new THREE.MeshStandardMaterial({ color: 0x888888, metalness: 0.3, roughness: 0.4 });
  }, [mode, accentColor]);

  return (
    <group ref={headRef} position={[0, 1.6, 0]}>
      {/* Head sphere */}
      <mesh material={headMaterial}>
        <sphereGeometry args={[0.7, 32, 32]} />
      </mesh>

      {/* Face plate */}
      <mesh position={[0, -0.1, 0.55]} material={headMaterial}>
        <cylinderGeometry args={[0.5, 0.5, 0.4, 32]} />
      </mesh>

      {/* Left Eye */}
      <mesh ref={leftEyeRef} position={[expr.left.x, expr.left.y, 0.72]}>
        <sphereGeometry args={[0.12 * expr.left.s, 16, 16]} />
        <meshStandardMaterial
          color={mode === 'B' ? '#00CCFF' : mode === 'C' ? accentColor : '#00FFCC'}
          emissive={mode === 'B' ? '#00CCFF' : mode === 'C' ? accentColor : '#00FFCC'}
          emissiveIntensity={mode === 'B' ? 0.5 : 0.3}
        />
      </mesh>

      {/* Right Eye */}
      <mesh ref={rightEyeRef} position={[expr.right.x, expr.right.y, 0.72]}>
        <sphereGeometry args={[0.12 * expr.right.s, 16, 16]} />
        <meshStandardMaterial
          color={mode === 'B' ? '#00CCFF' : mode === 'C' ? accentColor : '#00FFCC'}
          emissive={mode === 'B' ? '#00CCFF' : mode === 'C' ? accentColor : '#00FFCC'}
          emissiveIntensity={mode === 'B' ? 0.5 : 0.3}
        />
      </mesh>

      {/* Antenna */}
      <mesh position={[0, 0.85, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.4, 8]} />
        <meshStandardMaterial color={0x666666} metalness={0.5} roughness={0.3} />
      </mesh>

      {/* Antenna light */}
      <mesh ref={antennaRef} position={[0, 1.1, 0]}>
        <sphereGeometry args={[0.08, 16, 16]} />
        <meshStandardMaterial
          color="#FF3333"
          emissive="#FF3333"
          emissiveIntensity={0.8}
        />
      </mesh>

      {/* Mouth - emotion based */}
      <mesh position={[0, -0.25, 0.68]} rotation={[0.2, 0, 0]}>
        <torusGeometry args={[0.12, 0.02, 8, 16, emotion === 'happy' ? Math.PI : emotion === 'sad' ? Math.PI : Math.PI]} />
        <meshStandardMaterial color={mode === 'C' ? accentColor : 0x333333} />
      </mesh>
    </group>
  );
};

/* ─── Robot Body ─── */
interface RobotBodyProps {
  mode: RobotMode;
}

const RobotBody: React.FC<RobotBodyProps> = ({ mode }) => {
  const bodyRef = useRef<THREE.Group>(null);
  const accentColor = mode === 'C' ? '#00FFCC' : mode === 'B' ? '#00CCFF' : '#00FFCC';

  useFrame((state) => {
    if (!bodyRef.current) return;
    const t = state.clock.getElapsedTime();
    bodyRef.current.position.y = Math.sin(t * 1.5) * 0.05;
  });

  const bodyMaterial = useMemo(() => {
    if (mode === 'C') {
      return new THREE.MeshBasicMaterial({ color: accentColor, wireframe: true, transparent: true, opacity: 0.6 });
    }
    if (mode === 'B') {
      return new THREE.MeshStandardMaterial({ color: 0xaaaaaa, metalness: 0.9, roughness: 0.1 });
    }
    return new THREE.MeshStandardMaterial({ color: 0x777777, metalness: 0.3, roughness: 0.4 });
  }, [mode, accentColor]);

  return (
    <group ref={bodyRef}>
      {/* Main body */}
      <mesh position={[0, 0.5, 0]} material={bodyMaterial}>
        <cylinderGeometry args={[0.5, 0.6, 1.0, 32]} />
      </mesh>

      {/* Chest panel */}
      <mesh position={[0, 0.6, 0.45]}>
        <boxGeometry args={[0.4, 0.3, 0.05]} />
        <meshStandardMaterial
          color={mode === 'C' ? accentColor : mode === 'B' ? '#00CCFF' : '#00FFCC'}
          emissive={mode === 'C' ? accentColor : mode === 'B' ? '#00CCFF' : '#00FFCC'}
          emissiveIntensity={mode === 'C' ? 0.3 : 0.2}
          transparent={mode === 'C'}
          opacity={mode === 'C' ? 0.8 : 1}
        />
      </mesh>

      {/* Left arm */}
      <mesh position={[-0.7, 0.5, 0]} rotation={[0, 0, 0.3]}>
        <cylinderGeometry args={[0.08, 0.08, 0.7, 16]} />
        <meshStandardMaterial color={0x666666} metalness={0.4} roughness={0.3} />
      </mesh>

      {/* Right arm */}
      <mesh position={[0.7, 0.5, 0]} rotation={[0, 0, -0.3]}>
        <cylinderGeometry args={[0.08, 0.08, 0.7, 16]} />
        <meshStandardMaterial color={0x666666} metalness={0.4} roughness={0.3} />
      </mesh>

      {/* Left hand */}
      <mesh position={[-0.85, 0.15, 0]}>
        <sphereGeometry args={[0.1, 16, 16]} />
        <meshStandardMaterial color={0x555555} metalness={0.3} roughness={0.4} />
      </mesh>

      {/* Right hand */}
      <mesh position={[0.85, 0.15, 0]}>
        <sphereGeometry args={[0.1, 16, 16]} />
        <meshStandardMaterial color={0x555555} metalness={0.3} roughness={0.4} />
      </mesh>

      {/* Left leg */}
      <mesh position={[-0.25, -0.4, 0]}>
        <cylinderGeometry args={[0.1, 0.12, 0.5, 16]} />
        <meshStandardMaterial color={0x555555} metalness={0.3} roughness={0.4} />
      </mesh>

      {/* Right leg */}
      <mesh position={[0.25, -0.4, 0]}>
        <cylinderGeometry args={[0.1, 0.12, 0.5, 16]} />
        <meshStandardMaterial color={0x555555} metalness={0.3} roughness={0.4} />
      </mesh>

      {/* Left foot */}
      <mesh position={[-0.3, -0.7, 0.1]}>
        <boxGeometry args={[0.25, 0.1, 0.35]} />
        <meshStandardMaterial color={0x444444} metalness={0.3} roughness={0.4} />
      </mesh>

      {/* Right foot */}
      <mesh position={[0.3, -0.7, 0.1]}>
        <boxGeometry args={[0.25, 0.1, 0.35]} />
        <meshStandardMaterial color={0x444444} metalness={0.3} roughness={0.4} />
      </mesh>
    </group>
  );
};

/* ─── Mode B Particles ─── */
interface ParticlesProps {
  count: number;
}

const Particles: React.FC<ParticlesProps> = ({ count }) => {
  const origins = useMemo(() => {
    return Array.from({ length: count }, () => new THREE.Vector3(
      (Math.random() - 0.5) * 1.5,
      Math.random() * 0.5 + 0.3,
      (Math.random() - 0.5) * 1.0
    ));
  }, [count]);

  return (
    <>
      {origins.map((origin, i) => (
        <Particle key={i} origin={origin} />
      ))}
    </>
  );
};

/* ─── Scanline Effect for Mode C ─── */
const Scanline: React.FC = () => {
  const ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.getElapsedTime();
    ref.current.position.y = ((t * 0.8) % 4) - 1;
  });

  return (
    <mesh ref={ref} position={[0, -1, 0]}>
      <planeGeometry args={[3, 0.02]} />
      <meshBasicMaterial color="#00FFCC" transparent opacity={0.5} />
    </mesh>
  );
};

/* ─── Main Robot Scene ─── */
interface RobotSceneProps {
  mode: RobotMode;
  emotion: string;
}

const RobotScene: React.FC<RobotSceneProps> = ({ mode, emotion }) => {
  const mousePos = useRef({ x: 0, y: 0 });
  const { camera } = useThree();

  useEffect(() => {
    camera.position.set(0, 0.5, 4);
  }, [camera]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mousePos.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const accentColor = mode === 'C' ? '#00FFCC' : mode === 'B' ? '#00CCFF' : '#00FFCC';

  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 5, 5]} intensity={0.8} />
      <pointLight position={[-3, 3, 2]} intensity={0.5} color={accentColor} />

      {/* Stars for Mode B */}
      {mode === 'B' && <Stars radius={50} depth={50} count={1000} factor={4} saturation={0} fade speed={1} />}

      {/* Robot */}
      <group rotation={[0, mode === 'C' ? 0 : 0, 0]}>
        <RobotHead mode={mode} mousePos={mousePos} emotion={emotion} />
        <RobotBody mode={mode} />
      </group>

      {/* Particles for Mode B */}
      {mode === 'B' && <Particles count={30} />}

      {/* Scanline for Mode C */}
      {mode === 'C' && <Scanline />}

      {/* Ground reflection for Mode B */}
      {mode === 'B' && (
        <mesh position={[0, -0.8, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[10, 10]} />
          <meshStandardMaterial color={0x111111} metalness={0.9} roughness={0.1} />
        </mesh>
      )}

      <OrbitControls
        enableZoom={false}
        enablePan={false}
        maxPolarAngle={Math.PI / 1.5}
        minPolarAngle={Math.PI / 4}
        autoRotate={mode === 'C'}
        autoRotateSpeed={3}
      />
    </>
  );
};

/* ─── Exported Robot3D Component ─── */
interface Robot3DProps {
  mode: RobotMode;
}

const Robot3D: React.FC<Robot3DProps> = ({ mode }) => {
  const [emotion, setEmotion] = useState('happy');
  const emotions = ['happy', 'sad', 'angry', 'neutral'];

  useEffect(() => {
    if (mode !== 'A') return;
    let idx = 0;
    const interval = setInterval(() => {
      idx = (idx + 1) % emotions.length;
      setEmotion(emotions[idx]);
    }, 4000);
    return () => clearInterval(interval);
  }, [mode]);

  return (
    <div className="w-full h-full min-h-[400px]">
      <Canvas
        camera={{ fov: 50, near: 0.1, far: 100, position: [0, 0.5, 4] }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
      >
        <RobotScene mode={mode} emotion={emotion} />
      </Canvas>
    </div>
  );
};

export default Robot3D;
