import React from 'react';

const CRTEffect: React.FC = () => {
  return (
    <>
      {/* Scanlines overlay */}
      <div className="crt-scanlines" />
      
      {/* Vignette */}
      <div className="crt-vignette" />
      
      {/* Subtle flicker overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-[9996] crt-flicker"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(var(--primary), 0.01) 0%, transparent 70%)',
        }}
      />
    </>
  );
};

export default CRTEffect;
