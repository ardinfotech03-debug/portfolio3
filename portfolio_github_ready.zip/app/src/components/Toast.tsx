import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface ToastProps {
  message: string | null;
}

const Toast: React.FC<ToastProps> = ({ message }) => {
  return (
    <AnimatePresence>
      {message && (
        <motion.div
          initial={{ opacity: 0, y: 50, x: '-50%' }}
          animate={{ opacity: 1, y: 0, x: '-50%' }}
          exit={{ opacity: 0, y: 50, x: '-50%' }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-24 left-1/2 z-[9999] px-6 py-3 rounded-lg font-terminal text-sm"
          style={{
            background: 'var(--glass-bg)',
            backdropFilter: 'blur(12px)',
            border: '1px solid var(--accent-color)',
            color: 'var(--accent-color)',
            boxShadow: '0 0 30px rgba(var(--primary), 0.3)',
          }}
        >
          <span className="mr-2">{'>'}</span>
          {message}
          <span className="animate-blink ml-1">█</span>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Toast;
