import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Github, Linkedin } from 'lucide-react';
import GlassCard from '@/components/GlassCard';

const contactItems = [
  { icon: Mail, label: 'Email', value: 'alag123arasan@gmail.com', href: 'mailto:alag123arasan@gmail.com' },
  { icon: Phone, label: 'Phone', value: '+91 9003052804', href: 'tel:+919003052804' },
  { icon: MapPin, label: 'Location', value: 'Salem, Tamil Nadu', href: '#' },
];

const socialLinks = [
  { icon: Github, href: 'https://github.com/Alagarasan-D', label: 'GitHub' },
  { icon: Linkedin, href: 'https://www.linkedin.com/in/alagarasan-d-312021291/', label: 'LinkedIn' },
];

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const inputStyle = {
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,255,255,0.1)',
    color: 'var(--text-primary)',
  };

  return (
    <section
      id="contact"
      className="section-padding animate-section"
      style={{ backgroundColor: 'var(--bg-color)' }}
    >
      {/* Section Title */}
      <div className="text-center mb-12 animate-item">
        <h2
          className="font-display text-3xl md:text-4xl font-bold"
          style={{ color: 'var(--text-primary)' }}
        >
          GET IN TOUCH
        </h2>
        <div
          className="w-16 h-[3px] mx-auto mt-4"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-[1000px] mx-auto">
        {/* Left: Contact Info */}
        <div className="animate-item">
          <h3
            className="font-display text-2xl font-bold"
            style={{ color: 'var(--text-primary)' }}
          >
            Let's Connect
          </h3>
          <p
            className="font-body text-base font-light mt-3 leading-relaxed"
            style={{ color: 'var(--text-muted)' }}
          >
            Have a project in mind or want to collaborate? Feel free to reach out. 
            I'm always open to discussing new opportunities and creative ideas.
          </p>

          {/* Contact Items */}
          <div className="mt-8 space-y-5">
            {contactItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="flex items-center gap-4 group"
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: 'rgba(var(--primary), 0.1)' }}
                >
                  <item.icon
                    className="w-5 h-5"
                    style={{ color: 'var(--accent-color)' }}
                  />
                </div>
                <div>
                  <p
                    className="font-body text-xs uppercase tracking-wider"
                    style={{ color: 'var(--text-muted)' }}
                  >
                    {item.label}
                  </p>
                  <p
                    className="font-body text-base transition-colors duration-300 group-hover:text-[var(--accent-color)]"
                    style={{ color: 'var(--text-primary)' }}
                  >
                    {item.value}
                  </p>
                </div>
              </a>
            ))}
          </div>

          {/* Social Links */}
          <div className="flex gap-3 mt-8">
            {socialLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="glass-card w-10 h-10 flex items-center justify-center hover:scale-110 transition-all duration-300"
                aria-label={link.label}
              >
                <link.icon
                  className="w-4 h-4"
                  style={{ color: 'var(--text-primary)' }}
                />
              </a>
            ))}
          </div>
        </div>

        {/* Right: Contact Form */}
        <GlassCard className="animate-item">
          {submitted ? (
            <div className="text-center py-12">
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                style={{ backgroundColor: 'rgba(var(--primary), 0.1)' }}
              >
                <Send className="w-8 h-8" style={{ color: 'var(--accent-color)' }} />
              </div>
              <p
                className="font-display text-lg"
                style={{ color: 'var(--accent-color)' }}
              >
                Message Sent!
              </p>
              <p className="font-body text-sm mt-2" style={{ color: 'var(--text-muted)' }}>
                (Demo only — connect backend for real delivery)
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <input
                  type="text"
                  name="name"
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg font-body text-base outline-none transition-all duration-300 focus:border-[var(--accent-color)]"
                  style={inputStyle}
                />
              </div>
              <div>
                <input
                  type="email"
                  name="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg font-body text-base outline-none transition-all duration-300"
                  style={inputStyle}
                />
              </div>
              <div>
                <input
                  type="text"
                  name="subject"
                  placeholder="Subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 rounded-lg font-body text-base outline-none transition-all duration-300"
                  style={inputStyle}
                />
              </div>
              <div>
                <textarea
                  name="message"
                  placeholder="Your message..."
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 rounded-lg font-body text-base outline-none transition-all duration-300 resize-none"
                  style={inputStyle}
                />
              </div>
              <button
                type="submit"
                className="w-full py-3.5 rounded-lg font-display text-sm uppercase tracking-[2px] flex items-center justify-center gap-2 transition-all duration-300 hover:brightness-110 hover:scale-[1.02]"
                style={{
                  backgroundColor: 'var(--accent-color)',
                  color: 'var(--bg-color)',
                }}
              >
                Send Message
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}
        </GlassCard>
      </div>
    </section>
  );
};

export default Contact;
