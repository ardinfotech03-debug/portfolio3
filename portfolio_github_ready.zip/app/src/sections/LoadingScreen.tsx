import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface LoadingScreenProps {
  onComplete: () => void;
}

const bootLines = [
  '> BOOTING SYSTEM...',
  '> LOADING PORTFOLIO...',
  '> INITIALIZING ALAGARASAN.D...',
  '> MOUNTING 3D ASSETS...',
  '> RENDERING ROBOT...',
  '> SYSTEM READY.',
];

const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [currentLine, setCurrentLine] = useState(0);
  const [currentChar, setCurrentChar] = useState(0);
  const [progress, setProgress] = useState(0);
  const [glitching, setGlitching] = useState(false);
  const [visible, setVisible] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (currentLine >= bootLines.length) {
      // Start progress bar
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(progressInterval);
            setTimeout(() => {
              setGlitching(true);
              setTimeout(() => {
                setVisible(false);
                setTimeout(onComplete, 500);
              }, 500);
            }, 300);
            return 100;
          }
          return prev + 2;
        });
      }, 30);
      return () => clearInterval(progressInterval);
    }

    const line = bootLines[currentLine];
    if (currentChar < line.length) {
      intervalRef.current = setTimeout(() => {
        setCurrentChar((prev) => prev + 1);
      }, 50);
    } else {
      intervalRef.current = setTimeout(() => {
        setCurrentLine((prev) => prev + 1);
        setCurrentChar(0);
      }, 500);
    }

    return () => {
      if (intervalRef.current) clearTimeout(intervalRef.current);
    };
  }, [currentLine, currentChar, onComplete]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-0 z-[10000] flex items-center justify-center"
          style={{ backgroundColor: '#0A0A0A' }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="w-full max-w-[600px] px-8">
            {/* Boot text */}
            <div className="font-terminal text-base leading-[1.8]" style={{ color: '#33FF00' }}>
              {bootLines.slice(0, currentLine).map((line, i) => (
                <div key={i}>{line}</div>
              ))}
              {currentLine < bootLines.length && (
                <div>
                  {bootLines[currentLine].slice(0, currentChar)}
                  <span className="animate-blink">█</span>
                </div>
              )}
            </div>

            {/* Progress bar */}
            {currentLine >= bootLines.length && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="mt-8"
              >
                <div
                  className="w-full h-1 rounded"
                  style={{ background: 'rgba(51, 255, 0, 0.2)' }}
                >
                  <motion.div
                    className="h-full rounded"
                    style={{ background: '#33FF00', width: `${progress}%` }}
                  />
                </div>
                <div className="mt-2 font-terminal text-sm" style={{ color: '#33FF00' }}>
                  {progress}%
                </div>
              </motion.div>
            )}

            {/* Glitch overlay */}
            {glitching && (
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                {Array.from({ length: 10 }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute left-0 right-0"
                    style={{
                      top: `${i * 10}%`,
                      height: `${Math.random() * 5 + 2}%`,
                      background: Math.random() > 0.5 ? '#fff' : '#0A0A0A',
                      opacity: 0.8,
                    }}
                    animate={{
                      x: [0, (Math.random() - 0.5) * 40, 0],
                      opacity: [0, 0.8, 0],
                    }}
                    transition={{ duration: 0.5 }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* CRT scanlines */}
          <div className="crt-scanlines" />
          <div className="crt-vignette" />
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LoadingScreen;
