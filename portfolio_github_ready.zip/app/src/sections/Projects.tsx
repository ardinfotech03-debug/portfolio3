import React from 'react';
import { ExternalLink, Code } from 'lucide-react';
import GlassCard from '@/components/GlassCard';

const projects = [
  {
    name: 'Sprinkle Delight',
    description:
      'A delightful web application for discovering and sharing dessert recipes with beautiful UI.',
    link: 'https://sprinkle-delight.netlify.app/',
    tags: ['HTML', 'CSS', 'JavaScript'],
  },
  {
    name: 'Deivegam Nursery',
    description:
      'An elegant website for a plant nursery showcasing products, services, and gardening tips.',
    link: 'https://alagarasan-d.github.io/Deiveegam-Nursery/',
    tags: ['HTML', 'CSS', 'JavaScript'],
  },
  {
    name: 'Raja Cottons House',
    description:
      'Official website for Raja Cottons House featuring product catalog and business information.',
    link: 'https://raja-cottons-house.netlify.app/',
    tags: ['HTML', 'CSS', 'JavaScript'],
  },
];

const Projects: React.FC = () => {
  return (
    <section
      id="projects"
      className="section-padding animate-section"
      style={{ backgroundColor: 'var(--bg-color)' }}
    >
      {/* Section Title */}
      <div className="text-center mb-12 animate-item">
        <h2
          className="font-display text-3xl md:text-4xl font-bold"
          style={{ color: 'var(--text-primary)' }}
        >
          PROJECTS
        </h2>
        <div
          className="w-16 h-[3px] mx-auto mt-4"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      </div>

      {/* Project Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project, i) => (
          <GlassCard
            key={i}
            className="overflow-hidden p-0 group animate-item"
            hover
          >
            {/* Preview Area */}
            <div
              className="h-48 flex items-center justify-center relative overflow-hidden"
              style={{
                background: `linear-gradient(135deg, rgba(var(--primary), 0.2) 0%, rgba(var(--primary), 0.05) 100%)`,
              }}
            >
              <Code
                className="w-12 h-12 transition-transform duration-300 group-hover:scale-125"
                style={{ color: 'var(--accent-color)' }}
              />
              {/* Hover overlay */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center"
                style={{ backgroundColor: 'rgba(var(--primary), 0.1)' }}
              />
            </div>

            {/* Content Area */}
            <div className="p-5">
              <h3 className="font-display text-lg font-bold" style={{ color: 'var(--text-primary)' }}>
                {project.name}
              </h3>
              <p
                className="font-body text-sm mt-2 line-clamp-2"
                style={{ color: 'var(--text-muted)' }}
              >
                {project.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mt-3">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="font-terminal text-xs px-2 py-0.5 rounded border"
                    style={{
                      color: 'var(--accent-color)',
                      borderColor: 'rgba(var(--primary), 0.3)',
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Link */}
              <a
                href={project.link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 mt-4 font-terminal text-sm transition-all duration-300 hover:underline"
                style={{ color: 'var(--accent-color)' }}
              >
                Live Demo
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </GlassCard>
        ))}
      </div>
    </section>
  );
};

export default Projects;
