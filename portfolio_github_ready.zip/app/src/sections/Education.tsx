import React from 'react';
import { GraduationCap } from 'lucide-react';
import GlassCard from '@/components/GlassCard';

const Education: React.FC = () => {
  return (
    <section
      id="education"
      className="section-padding animate-section"
      style={{ backgroundColor: 'var(--bg-color)' }}
    >
      {/* Section Title */}
      <div className="text-center mb-12 animate-item">
        <h2
          className="font-display text-3xl md:text-4xl font-bold"
          style={{ color: 'var(--text-primary)' }}
        >
          EDUCATION
        </h2>
        <div
          className="w-16 h-[3px] mx-auto mt-4"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      </div>

      {/* Education Card */}
      <div className="max-w-[700px] mx-auto animate-item">
        <GlassCard className="text-center py-10 px-8">
          <GraduationCap
            className="w-12 h-12 mx-auto mb-4"
            style={{ color: 'var(--accent-color)' }}
          />
          <h3
            className="font-display text-xl md:text-2xl font-bold"
            style={{ color: 'var(--text-primary)' }}
          >
            Bachelor of Computer Science
          </h3>
          <p
            className="font-body text-base md:text-lg mt-2"
            style={{ color: 'var(--text-primary)' }}
          >
            Muthayammal Memorial College of Arts & Science
          </p>
          <p
            className="font-body text-sm md:text-base mt-1"
            style={{ color: 'var(--text-muted)' }}
          >
            Rasipuram, Tamil Nadu
          </p>
          <span
            className="inline-block mt-4 font-terminal text-sm px-4 py-1 rounded-full border"
            style={{
              color: 'var(--accent-color)',
              borderColor: 'var(--accent-color)',
            }}
          >
            2021 — 2026
          </span>
        </GlassCard>
      </div>
    </section>
  );
};

export default Education;
