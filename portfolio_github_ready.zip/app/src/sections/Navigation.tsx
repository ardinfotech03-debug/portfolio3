import React, { useState, useEffect } from 'react';
import { Menu, X, Bot } from 'lucide-react';
import GlitchText from '@/components/GlitchText';

interface NavigationProps {
  onNavigate: (id: string) => void;
}

const navLinks = [
  { label: 'Home', id: 'home' },
  { label: 'About', id: 'about' },
  { label: 'Education', id: 'education' },
  { label: 'Internship', id: 'internship' },
  { label: 'Projects', id: 'projects' },
  { label: 'Skills', id: 'skills' },
  { label: 'Certificates', id: 'certificates' },
  { label: 'Reviews', id: 'reviews' },
  { label: 'Contact', id: 'contact' },
];

const Navigation: React.FC<NavigationProps> = ({ onNavigate }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);

      const sections = navLinks.map((l) => {
        const el = document.getElementById(l.id);
        if (!el) return { id: l.id, top: 0 };
        const rect = el.getBoundingClientRect();
        return { id: l.id, top: rect.top };
      });

      const current = sections.reduce((closest, section) => {
        if (section.top <= 150 && section.top > closest.top) return section;
        return closest;
      }, { id: 'home', top: -Infinity });

      setActiveSection(current.id);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = (id: string) => {
    onNavigate(id);
    setMobileOpen(false);
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-300 ${
          scrolled ? 'bg-[rgba(6,6,16,0.9)] backdrop-blur-xl' : 'bg-transparent'
        }`}
      >
        <div className="max-w-[1200px] mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleClick('home')}
            className="flex items-center gap-2 group"
          >
            <Bot className="w-5 h-5" style={{ color: 'var(--accent-color)' }} />
            <GlitchText
              text="ALAGARASAN.D"
              className="font-display text-sm md:text-base font-bold tracking-[3px]"
            />
          </button>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleClick(link.id)}
                className={`font-body text-xs uppercase tracking-[1px] transition-colors duration-300 relative ${
                  activeSection === link.id
                    ? 'text-[var(--accent-color)]'
                    : 'text-[var(--text-primary)] hover:text-[var(--accent-color)]'
                }`}
              >
                {link.label}
                {activeSection === link.id && (
                  <span
                    className="absolute -bottom-1 left-0 w-full h-0.5"
                    style={{ backgroundColor: 'var(--accent-color)' }}
                  />
                )}
              </button>
            ))}
          </div>

          {/* Mobile Hamburger */}
          <button
            className="lg:hidden p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? (
              <X className="w-6 h-6 text-[var(--text-primary)]" />
            ) : (
              <Menu className="w-6 h-6 text-[var(--text-primary)]" />
            )}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-[99] lg:hidden flex flex-col items-center justify-center gap-6"
          style={{
            backgroundColor: 'rgba(6, 6, 16, 0.98)',
            backdropFilter: 'blur(20px)',
          }}
        >
          {navLinks.map((link, i) => (
            <button
              key={link.id}
              onClick={() => handleClick(link.id)}
              className="font-display text-xl uppercase tracking-[2px] transition-colors duration-300"
              style={{
                color: activeSection === link.id ? 'var(--accent-color)' : 'var(--text-primary)',
                animationDelay: `${i * 0.05}s`,
              }}
            >
              {link.label}
            </button>
          ))}
        </div>
      )}
    </>
  );
};

export default Navigation;
