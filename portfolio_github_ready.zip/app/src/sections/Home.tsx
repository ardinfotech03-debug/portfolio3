import React, { lazy, Suspense } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Download, ExternalLink, MessageSquare } from 'lucide-react';
import GlitchText from '@/components/GlitchText';
import type { RobotMode } from '@/types';

const Robot3D = lazy(() => import('@/components/Robot3D'));

interface HomeProps {
  robotMode: RobotMode;
  onNavigate: (id: string) => void;
}

const Home: React.FC<HomeProps> = ({ robotMode, onNavigate }) => {
  return (
    <section
      id="home"
      className="min-h-[100dvh] flex items-center relative overflow-hidden"
      style={{ backgroundColor: 'var(--bg-color)' }}
    >
      {/* Subtle background gradient */}
      <div
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          background: `radial-gradient(ellipse at 50% 50%, var(--accent-color) 0%, transparent 70%)`,
        }}
      />

      <div className="w-full max-w-[1200px] mx-auto px-4 md:px-8 py-20 flex flex-col lg:flex-row items-center gap-8 lg:gap-4">
        {/* Left: Text Content */}
        <div className="flex-1 text-center lg:text-left z-10">
          <motion.div
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            <h1
              className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight glow-text"
              style={{ color: 'var(--accent-color)' }}
            >
              <GlitchText text="ALAGARASAN D" interval={8000} />
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="font-body text-lg md:text-xl font-light mt-4"
            style={{ color: 'var(--text-muted)' }}
          >
            Web Developer & UI/UX Designer
          </motion.p>

          <motion.blockquote
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 1.1 }}
            className="mt-6 font-terminal text-sm md:text-base italic border-l-[3px] pl-4 max-w-lg mx-auto lg:mx-0"
            style={{
              borderColor: 'var(--accent-color)',
              color: 'var(--text-primary)',
              opacity: 0.7,
            }}
          >
            "Turning ideas into elegant digital products, one pixel at a time."
          </motion.blockquote>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.4 }}
            className="mt-8 flex flex-wrap gap-4 justify-center lg:justify-start"
          >
            <button
              onClick={() => onNavigate('projects')}
              className="btn-primary flex items-center gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              View Projects
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="btn-secondary flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              Contact Me
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.7 }}
            className="mt-4"
          >
            <button
              className="px-6 py-2 rounded-lg border font-display text-xs uppercase tracking-[2px] transition-all duration-300 opacity-60 hover:opacity-100 flex items-center gap-2 mx-auto lg:mx-0"
              style={{
                borderColor: 'var(--accent-color)',
                color: 'var(--accent-color)',
              }}
              title="Coming soon - upload your resume PDF"
              onClick={() => alert('Resume upload coming soon!')}
            >
              <Download className="w-4 h-4" />
              Resume
            </button>
          </motion.div>
        </div>

        {/* Right: Robot */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.3, type: 'spring' }}
          className="flex-1 w-full h-[350px] md:h-[450px] lg:h-[500px]"
        >
          <Suspense
            fallback={
              <div className="w-full h-full flex items-center justify-center">
                <div
                  className="w-16 h-16 border-4 border-t-transparent rounded-full animate-spin"
                  style={{ borderColor: 'var(--accent-color)', borderTopColor: 'transparent' }}
                />
              </div>
            }
          >
            <Robot3D mode={robotMode} />
          </Suspense>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <button
          onClick={() => onNavigate('about')}
          className="animate-bounce-slow"
          style={{ color: 'var(--text-muted)' }}
          aria-label="Scroll down"
        >
          <ChevronDown className="w-6 h-6" />
        </button>
      </motion.div>
    </section>
  );
};

export default Home;
