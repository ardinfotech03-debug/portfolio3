import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, Phone } from 'lucide-react';

const socialLinks = [
  { icon: Github, href: 'https://github.com/Alagarasan-D', label: 'GitHub' },
  { icon: Linkedin, href: 'https://www.linkedin.com/in/alagarasan-d-312021291/', label: 'LinkedIn' },
  { icon: Mail, href: 'mailto:alag123arasan@gmail.com', label: 'Email' },
  { icon: Phone, href: 'tel:+919003052804', label: 'Call' },
];

const About: React.FC = () => {
  return (
    <section
      id="about"
      className="section-padding animate-section"
      style={{
        backgroundColor: 'var(--bg-color)',
        backgroundImage:
          'linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)',
        backgroundSize: '50px 50px',
      }}
    >
      <div className="flex flex-col lg:flex-row gap-12 items-start">
        {/* Left: Section Label */}
        <div className="lg:w-[30%] animate-item">
          <div
            className="w-10 h-0.5 mb-4"
            style={{ backgroundColor: 'var(--accent-color)' }}
          />
          <p
            className="font-terminal text-sm uppercase tracking-[4px]"
            style={{ color: 'var(--accent-color)' }}
          >
            ABOUT ME
          </p>
        </div>

        {/* Right: Bio + Social */}
        <div className="lg:w-[70%]">
          <motion.p
            className="font-body text-base md:text-lg font-light leading-[1.8] animate-item"
            style={{ color: 'var(--text-primary)' }}
          >
            I'm Alagarasan, a passionate Web Developer from Muthayammal Memorial College of Arts 
            & Science. I specialize in building immersive web experiences that combine clean code 
            with creative design.
          </motion.p>

          <motion.p
            className="font-body text-base md:text-lg font-light leading-[1.8] mt-4 animate-item"
            style={{ color: 'var(--text-primary)' }}
          >
            Based in Salem, Tamil Nadu, I turn ideas into elegant digital products. My journey in 
            tech started with a curiosity for how things work on the web, and that curiosity has 
            driven me to master modern web technologies and design tools.
          </motion.p>

          <motion.p
            className="font-body text-base md:text-lg font-light leading-[1.8] mt-4 animate-item"
            style={{ color: 'var(--text-primary)' }}
          >
            When I'm not coding, you'll find me exploring new design trends, contributing to 
            open-source projects, or sketching UI concepts. I believe great software is born at 
            the intersection of technical excellence and human-centered design.
          </motion.p>

          {/* Social Links */}
          <div className="flex gap-3 mt-8 animate-item">
            {socialLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="glass-card w-12 h-12 flex items-center justify-center hover:scale-110 transition-all duration-300 group"
                aria-label={link.label}
              >
                <link.icon
                  className="w-5 h-5 transition-colors duration-300"
                  style={{ color: 'var(--text-primary)' }}
                />
                <style>{`.group:hover svg { color: var(--accent-color) !important; }`}</style>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
