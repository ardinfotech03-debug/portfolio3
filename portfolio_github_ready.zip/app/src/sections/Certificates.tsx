import React from 'react';
import { Award } from 'lucide-react';
import GlassCard from '@/components/GlassCard';

const certificates = [
  {
    title: 'HTML, CSS, JS & Web Development',
    issuer: 'Infosys Springboard',
  },
  {
    title: 'UI/UX Design & Web Development',
    issuer: 'Codec Technologies',
  },
];

const Certificates: React.FC = () => {
  return (
    <section
      id="certificates"
      className="section-padding animate-section"
      style={{ backgroundColor: 'var(--bg-color)' }}
    >
      {/* Section Title */}
      <div className="text-center mb-12 animate-item">
        <h2
          className="font-display text-3xl md:text-4xl font-bold"
          style={{ color: 'var(--text-primary)' }}
        >
          CERTIFICATES
        </h2>
        <div
          className="w-16 h-[3px] mx-auto mt-4"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      </div>

      {/* Certificate Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[800px] mx-auto">
        {certificates.map((cert, i) => (
          <GlassCard
            key={i}
            className="text-center py-8 px-6 relative overflow-hidden group animate-item"
            hover
          >
            {/* Top gradient border */}
            <div
              className="absolute top-0 left-0 right-0 h-[3px]"
              style={{
                background: `linear-gradient(90deg, var(--accent-color), var(--accent-secondary))`,
              }}
            />

            <Award
              className="w-12 h-12 mx-auto mb-4 transition-transform duration-300 group-hover:scale-110"
              style={{ color: 'var(--accent-color)' }}
            />
            <h3
              className="font-display text-lg md:text-xl font-bold"
              style={{ color: 'var(--text-primary)' }}
            >
              {cert.title}
            </h3>
            <p
              className="font-body text-sm md:text-base mt-2"
              style={{ color: 'var(--text-muted)' }}
            >
              {cert.issuer}
            </p>
          </GlassCard>
        ))}
      </div>
    </section>
  );
};

export default Certificates;
