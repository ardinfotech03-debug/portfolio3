import React from 'react';
import { Star } from 'lucide-react';
import GlassCard from '@/components/GlassCard';

const reviews = [
  {
    name: 'Priya K.',
    role: 'Project Manager',
    review:
      'Alagarasan delivered exceptional work on our web project. His attention to detail and creative approach to UI design made our platform stand out. Highly recommended!',
    rating: 5,
    initials: 'PK',
  },
  {
    name: 'Rahul M.',
    role: 'Senior Developer',
    review:
      'Working with Alagarasan was a great experience. His frontend skills are solid, and he brings fresh ideas to every project. A talented developer with a bright future.',
    rating: 5,
    initials: 'RM',
  },
  {
    name: 'Sneha R.',
    role: 'UX Designer',
    review:
      'The dedication and passion Alagarasan puts into his work is inspiring. He created a beautiful, responsive website for our team that exceeded all expectations.',
    rating: 5,
    initials: 'SR',
  },
];

const Reviews: React.FC = () => {
  return (
    <section
      id="reviews"
      className="section-padding animate-section"
      style={{ backgroundColor: 'var(--bg-color)' }}
    >
      {/* Section Title */}
      <div className="text-center mb-12 animate-item">
        <h2
          className="font-display text-3xl md:text-4xl font-bold"
          style={{ color: 'var(--text-primary)' }}
        >
          REVIEWS
        </h2>
        <div
          className="w-16 h-[3px] mx-auto mt-4"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      </div>

      {/* Reviews Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {reviews.map((review, i) => (
          <GlassCard key={i} className="relative animate-item" hover>
            {/* Quote mark */}
            <span
              className="absolute top-4 left-4 font-display text-6xl leading-none select-none pointer-events-none"
              style={{ color: 'var(--accent-color)', opacity: 0.15 }}
            >
              "
            </span>

            {/* Review text */}
            <p
              className="font-body text-sm md:text-base font-light italic leading-relaxed mt-6"
              style={{ color: 'var(--text-primary)' }}
            >
              {review.review}
            </p>

            {/* Stars */}
            <div className="flex gap-1 mt-4">
              {Array.from({ length: review.rating }).map((_, j) => (
                <Star
                  key={j}
                  className="w-4 h-4 fill-current"
                  style={{ color: 'var(--accent-color)' }}
                />
              ))}
            </div>

            {/* Author */}
            <div className="flex items-center gap-3 mt-5 pt-4 border-t" style={{ borderColor: 'var(--glass-border)' }}>
              {/* Avatar */}
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center font-display text-sm font-bold"
                style={{
                  backgroundColor: 'rgba(var(--primary), 0.2)',
                  color: 'var(--accent-color)',
                }}
              >
                {review.initials}
              </div>
              <div>
                <p
                  className="font-body text-base font-medium"
                  style={{ color: 'var(--text-primary)' }}
                >
                  {review.name}
                </p>
                <p
                  className="font-body text-sm"
                  style={{ color: 'var(--text-muted)' }}
                >
                  {review.role}
                </p>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>
    </section>
  );
};

export default Reviews;
