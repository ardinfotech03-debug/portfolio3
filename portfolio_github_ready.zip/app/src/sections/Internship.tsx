import React from 'react';
import { Briefcase, Code, Palette } from 'lucide-react';

const internships = [
  {
    role: 'UI/UX Design Intern',
    company: 'Codec Technologies',
    location: 'Coimbatore',
    duration: 'Jan 2026 — Feb 2026',
    Icon: Palette,
  },
  {
    role: 'Web Development Intern',
    company: 'Codec Technologies',
    location: 'Coimbatore',
    duration: 'Jan 2026 — Feb 2026',
    Icon: Code,
  },
  {
    role: 'Digital Marketing Intern',
    company: 'Optimus Technocrates India Pvt Ltd',
    location: 'Salem',
    duration: 'May 2025 — Jun 2025',
    Icon: Briefcase,
  },
];

const Internship: React.FC = () => {
  return (
    <section
      id="internship"
      className="section-padding animate-section"
      style={{ backgroundColor: 'var(--bg-color)' }}
    >
      {/* Section Title */}
      <div className="text-center mb-12 animate-item">
        <h2
          className="font-display text-3xl md:text-4xl font-bold"
          style={{ color: 'var(--text-primary)' }}
        >
          INTERNSHIPS
        </h2>
        <div
          className="w-16 h-[3px] mx-auto mt-4"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      </div>

      {/* Timeline */}
      <div className="max-w-[800px] mx-auto relative">
        {/* Timeline line - desktop only */}
        <div
          className="hidden md:block absolute left-[24px] top-0 bottom-0 w-0.5"
          style={{ backgroundColor: 'rgba(var(--primary), 0.3)' }}
        />

        {internships.map((intern, i) => (
          <div key={i} className="relative flex gap-6 mb-8 last:mb-0 animate-item">
            {/* Timeline dot */}
            <div
              className="hidden md:flex w-12 h-12 rounded-full items-center justify-center flex-shrink-0 z-10"
              style={{
                backgroundColor: 'var(--bg-color)',
                border: '2px solid var(--accent-color)',
              }}
            >
              <intern.Icon
                className="w-5 h-5"
                style={{ color: 'var(--accent-color)' }}
              />
            </div>

            {/* Card */}
            <div className="flex-1 glass-card p-6 border-l-[3px]" style={{ borderLeftColor: 'var(--accent-color)' }}>
              <div className="flex md:hidden items-center gap-3 mb-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center"
                  style={{
                    backgroundColor: 'rgba(var(--primary), 0.1)',
                  }}
                >
                  <intern.Icon
                    className="w-5 h-5"
                    style={{ color: 'var(--accent-color)' }}
                  />
                </div>
              </div>
              <h3
                className="font-body text-lg md:text-xl font-bold"
                style={{ color: 'var(--accent-color)' }}
              >
                {intern.company}
              </h3>
              <p
                className="font-body text-base mt-1"
                style={{ color: 'var(--text-primary)' }}
              >
                {intern.role}
              </p>
              <p
                className="font-body text-sm mt-1"
                style={{ color: 'var(--text-muted)' }}
              >
                {intern.location}
              </p>
              <span
                className="inline-block mt-3 font-terminal text-xs px-3 py-1 rounded-full"
                style={{
                  color: 'var(--accent-color)',
                  backgroundColor: 'rgba(var(--primary), 0.1)',
                }}
              >
                {intern.duration}
              </span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Internship;
