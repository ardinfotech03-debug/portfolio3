import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

const skills = [
  { name: 'HTML', color: '#E34F26' },
  { name: 'CSS', color: '#1572B6' },
  { name: 'JavaScript', color: '#F7DF1E' },
  { name: 'Figma', color: '#F24E1E' },
  { name: 'Adobe', color: '#FF0000' },
  { name: 'GitHub', color: '#888888' },
  { name: 'VS Code', color: '#007ACC' },
];

/* ─── Single Skill Cube ─── */
interface SkillCubeProps {
  position: [number, number, number];
  color: string;
  name: string;
  speed: number;
  phase: number;
}

const SkillCube: React.FC<SkillCubeProps> = ({ position, color, speed, phase }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const labelRef = useRef<THREE.Mesh>(null);

  const labelTexture = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 64;
    const context = canvas.getContext('2d');
    if (context) {
      context.fillStyle = 'rgba(0,0,0,0)';
      context.fillRect(0, 0, 256, 64);
      context.font = 'bold 32px Inter, sans-serif';
      context.fillStyle = '#ffffff';
      context.textAlign = 'center';
      context.textBaseline = 'middle';
      context.fillText(String(name), 128, 32);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    return texture;
  }, [name]);

  useFrame((state) => {
    if (!meshRef.current) return;
    const t = state.clock.getElapsedTime();

    // Rotation
    meshRef.current.rotation.x += 0.01 * speed;
    meshRef.current.rotation.y += 0.02 * speed;

    // Floating
    meshRef.current.position.y = position[1] + Math.sin(t * speed + phase) * 0.3;

    // Label follows cube
    if (labelRef.current) {
      labelRef.current.position.x = meshRef.current.position.x;
      labelRef.current.position.y = meshRef.current.position.y - 1;
      labelRef.current.position.z = meshRef.current.position.z;
      labelRef.current.lookAt(state.camera.position);
    }
  });

  return (
    <>
      <mesh ref={meshRef} position={position}>
        <boxGeometry args={[0.8, 0.8, 0.8]} />
        <meshStandardMaterial
          color={color}
          metalness={0.5}
          roughness={0.3}
          emissive={color}
          emissiveIntensity={0.2}
        />
      </mesh>
      <sprite ref={labelRef} position={[position[0], position[1] - 1, position[2]]} scale={[1.5, 0.375, 1]}>
        <spriteMaterial map={labelTexture} transparent opacity={0.9} />
      </sprite>
    </>
  );
};

/* ─── Skill Cubes Scene ─── */
const SkillCubesScene: React.FC = () => {
  const positions: [number, number, number][] = [
    [-3, 0, 0],
    [-2, 0.5, 0.5],
    [-1, -0.3, -0.5],
    [0, 0.2, 0],
    [1, -0.2, 0.5],
    [2, 0.4, -0.5],
    [3, 0, 0],
  ];

  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 5, 5]} intensity={0.8} />
      <pointLight position={[-5, 3, 2]} intensity={0.3} />

      {skills.map((skill, i) => (
        <SkillCube
          key={skill.name}
          position={positions[i]}
          color={skill.color}
          name={skill.name}
          speed={0.8 + Math.random() * 0.5}
          phase={i * 0.8}
        />
      ))}
    </>
  );
};

const Skills: React.FC = () => {
  return (
    <section
      id="skills"
      className="section-padding animate-section"
      style={{
        backgroundColor: 'var(--bg-color)',
        backgroundImage: `radial-gradient(circle at 50% 50%, rgba(var(--primary), 0.05) 0%, transparent 70%)`,
      }}
    >
      {/* Section Title */}
      <div className="text-center mb-8 animate-item">
        <h2
          className="font-display text-3xl md:text-4xl font-bold"
          style={{ color: 'var(--text-primary)' }}
        >
          SKILLS
        </h2>
        <div
          className="w-16 h-[3px] mx-auto mt-4"
          style={{ backgroundColor: 'var(--accent-color)' }}
        />
      </div>

      {/* 3D Cubes Canvas - desktop only */}
      <div className="hidden md:block h-[400px] w-full animate-item">
        <Canvas camera={{ position: [0, 0, 6], fov: 50 }} dpr={[1, 2]}>
          <SkillCubesScene />
        </Canvas>
      </div>

      {/* Skill Tags - always visible, mobile fallback */}
      <div className="flex flex-wrap justify-center gap-3 mt-6 animate-item">
        {skills.map((skill) => (
          <span
            key={skill.name}
            className="glass-card px-4 py-2 font-terminal text-sm transition-all duration-300 hover:scale-105 cursor-default"
            style={{
              color: 'var(--text-primary)',
              borderColor: skill.color + '40',
            }}
            onMouseEnter={(e) => {
              (e.target as HTMLElement).style.color = skill.color;
              (e.target as HTMLElement).style.borderColor = skill.color;
              (e.target as HTMLElement).style.boxShadow = `0 0 20px ${skill.color}30`;
            }}
            onMouseLeave={(e) => {
              (e.target as HTMLElement).style.color = 'var(--text-primary)';
              (e.target as HTMLElement).style.borderColor = skill.color + '40';
              (e.target as HTMLElement).style.boxShadow = 'none';
            }}
          >
            {skill.name}
          </span>
        ))}
      </div>
    </section>
  );
};

export default Skills;
