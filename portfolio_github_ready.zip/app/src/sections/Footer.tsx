import React from 'react';

interface FooterProps {
  themeName: string;
  onCycleTheme: () => void;
  onNavigate: (id: string) => void;
}

const Footer: React.FC<FooterProps> = ({ themeName, onCycleTheme, onNavigate }) => {
  const shortcuts = [
    { label: 'Home', id: 'home' },
    { label: 'About', id: 'about' },
    { label: 'Projects', id: 'projects' },
    { label: 'Contact', id: 'contact' },
  ];

  return (
    <footer
      className="py-10 px-4"
      style={{
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        borderTop: '1px solid rgba(255, 255, 255, 0.05)',
      }}
    >
      <div className="max-w-[1200px] mx-auto text-center">
        {/* Copyright + Theme Switcher */}
        <p
          className="font-terminal text-sm"
          style={{ color: 'var(--text-muted)' }}
        >
          &copy; 2025 Alagarasan D. All rights reserved. Built with passion and pixels.{" "}
          <button
            onClick={onCycleTheme}
            className="inline-flex items-center gap-1 ml-2 px-2 py-0.5 rounded font-terminal text-xs transition-all duration-300 hover:opacity-80"
            style={{
              color: 'var(--accent-color)',
              border: '1px solid rgba(var(--primary), 0.3)',
            }}
            title="Click to cycle theme"
          >
            [ Theme: {themeName} ]
          </button>
        </p>

        {/* Navigation Shortcuts */}
        <div className="flex items-center justify-center gap-4 mt-4">
          {shortcuts.map((link, i) => (
            <React.Fragment key={link.id}>
              {i > 0 && (
                <span style={{ color: 'var(--text-muted)', opacity: 0.4 }}>·</span>
              )}
              <button
                onClick={() => onNavigate(link.id)}
                className="font-body text-xs transition-colors duration-300 hover:text-[var(--accent-color)]"
                style={{ color: 'var(--text-muted)' }}
              >
                {link.label}
              </button>
            </React.Fragment>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
