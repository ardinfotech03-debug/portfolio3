export type ThemeName = 'Dark Navy + Gold' | 'Dark Cyan/Teal' | 'Dark Purple/Violet' | 'Minimal Pro' | 'Trendy Dark' | 'Creative Designer';

export interface Theme {
  name: ThemeName;
  bg: string;
  text: string;
  accent: string;
  accentSecondary: string;
}

export type RobotMode = 'A' | 'B' | 'C';

export interface Project {
  name: string;
  description: string;
  link: string;
  tags: string[];
  icon: string;
}

export interface Internship {
  role: string;
  company: string;
  location: string;
  duration: string;
  icon: string;
}

export interface Certificate {
  title: string;
  issuer: string;
}

export interface Review {
  name: string;
  role: string;
  review: string;
  rating: number;
  initials: string;
}

export interface Skill {
  name: string;
  color: string;
}

export interface ContactInfo {
  label: string;
  value: string;
  icon: string;
  href: string;
}

export const THEMES: Theme[] = [
  { name: 'Dark Navy + Gold', bg: '#0D1B2A', text: '#E0E1DD', accent: '#FFD700', accentSecondary: '#FFC300' },
  { name: 'Dark Cyan/Teal', bg: '#060610', text: '#E0FBFC', accent: '#00FFCC', accentSecondary: '#00CCFF' },
  { name: 'Dark Purple/Violet', bg: '#0D0D1F', text: '#E0E0FF', accent: '#A855F7', accentSecondary: '#C084FC' },
  { name: 'Minimal Pro', bg: '#0F172A', text: '#F1F5F9', accent: '#38BDF8', accentSecondary: '#7DD3FC' },
  { name: 'Trendy Dark', bg: '#111827', text: '#F9FAFB', accent: '#A855F7', accentSecondary: '#22C55E' },
  { name: 'Creative Designer', bg: '#1E293B', text: '#F8FAFC', accent: '#F59E0B', accentSecondary: '#EC4899' },
];

export const DEFAULT_THEME_INDEX = 1;
