import { useState, useEffect, useCallback } from 'react';
import { THEMES, DEFAULT_THEME_INDEX, type ThemeName } from '@/types';

export function useTheme() {
  const [themeIndex, setThemeIndex] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('portfolio-theme-index');
      return saved ? parseInt(saved, 10) : DEFAULT_THEME_INDEX;
    }
    return DEFAULT_THEME_INDEX;
  });

  const theme = THEMES[themeIndex];

  const applyTheme = useCallback((index: number) => {
    const t = THEMES[index];
    const root = document.documentElement;
    
    root.style.setProperty('--bg-color', t.bg);
    root.style.setProperty('--text-primary', t.text);
    root.style.setProperty('--accent-color', t.accent);
    root.style.setProperty('--accent-secondary', t.accentSecondary);
    
    const r = parseInt(t.accent.slice(1, 3), 16);
    const g = parseInt(t.accent.slice(3, 5), 16);
    const b = parseInt(t.accent.slice(5, 7), 16);
    root.style.setProperty('--primary', `${r}, ${g}, ${b}`);
    root.style.setProperty('--accent', `${r}, ${g}, ${b}`);
    root.style.setProperty('--ring', `${r}, ${g}, ${b}`);
    
    document.body.style.backgroundColor = t.bg;
    document.body.style.color = t.text;
  }, []);

  useEffect(() => {
    applyTheme(themeIndex);
    localStorage.setItem('portfolio-theme-index', themeIndex.toString());
  }, [themeIndex, applyTheme]);

  const cycleTheme = useCallback(() => {
    setThemeIndex((prev) => (prev + 1) % THEMES.length);
  }, []);

  const setThemeByName = useCallback((name: ThemeName) => {
    const index = THEMES.findIndex((t) => t.name === name);
    if (index >= 0) setThemeIndex(index);
  }, []);

  return { theme, themeIndex, cycleTheme, setThemeByName };
}
