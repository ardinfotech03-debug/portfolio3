import { useState, useCallback, useRef } from 'react';
import type { RobotMode } from '@/types';

export function useRobotMode() {
  const [mode, setMode] = useState<RobotMode>('A');
  const [toast, setToast] = useState<string | null>(null);
  const toastTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const cycleMode = useCallback(() => {
    setMode((prev) => {
      const next = prev === 'A' ? 'B' : prev === 'B' ? 'C' : 'A';
      const messages: Record<RobotMode, string> = {
        A: 'Robot Mode A: Emotional',
        B: 'Robot Mode B: Metallic Upgrade',
        C: 'Robot Mode C: Hologram',
      };
      
      if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
      setToast(messages[next]);
      toastTimeoutRef.current = setTimeout(() => setToast(null), 3000);
      
      return next;
    });
  }, []);

  return { mode, cycleMode, toast, setToast };
}
